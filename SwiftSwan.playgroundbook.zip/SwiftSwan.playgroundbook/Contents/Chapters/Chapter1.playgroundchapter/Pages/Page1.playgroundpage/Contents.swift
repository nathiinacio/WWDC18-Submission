/*:
 # Welcome To Swift Swan!
 
 You will meet Nathalia, she is our ballerina and she is in the middle of her Swan Lake presentation. But she has a problem...
 
 ### She forgot the coreography!
 
 That's right, our girl got too nervous and doesn't know what to do.
 
 ### But you can help her out!
 
 ## What can you do?
 
 Don't worry, it's very simple:
 
 * Tap in the white feathers to make her dance the white swan.

 ![White Feather](white_feather.png)
 
 * Tap in the black feathers to make her dance the black swan.
 
 ![Black Feather](black_feather.png)
 
 ## Easy, right?
 
 
 ### Let's go to the next page to go to the theather!
 
 */


