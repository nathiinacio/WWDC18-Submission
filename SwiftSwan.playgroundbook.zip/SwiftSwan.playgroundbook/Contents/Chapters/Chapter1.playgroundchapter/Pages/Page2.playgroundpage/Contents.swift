
/*:
 
 # Now it's the time!
 
 You have the challenge to make her dance for 20 seconds. You can look at the timer in the teather.
 
 ![Timer](timer.png)
 
 After that, she will remember the dance all by herself. Sounds easy, right?
 
 ## But you shall remember:
 
 * The white swan is very perfect and graceful, but it also can be too frigid!
 
 * In the other hand, the black swan is very spontaneous and impulsive, but it also can be too wild!
 
 ## Choose your swan wisely!
 
 * Callout(Tip):
 Try to make a sequence of two feathers of the same color to see what happens!
 
 ### Please, put in landscape and full screen to enjoy the full show!
 
 ## Good Luck!
 
 ### Credits:
 
 Musics: Swan Lake by Piotr Ilitch Tchaikovsky at public domain.
 
 */
 

//#-hidden-code

import PlaygroundSupport
import SpriteKit



let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 880))

if let scene = GameScene(fileNamed: "GameScene") {
    
    //let scene = GameScene(size: sceneView.frame.size)
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    
    // Present the scene
    sceneView.presentScene(scene)
    
}


PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
