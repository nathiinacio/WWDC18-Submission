
import PlaygroundSupport
import SpriteKit



let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 880))

if let scene = GameScene(fileNamed: "GameScene") {
    
    //let scene = GameScene(size: sceneView.frame.size)
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    
    // Present the scene
    sceneView.presentScene(scene)
    
}


PlaygroundPage.current.liveView = sceneView
