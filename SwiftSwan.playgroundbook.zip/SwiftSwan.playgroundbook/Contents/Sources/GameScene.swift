//
//  GameScene.swift
//  Swift Swan
//
//  Created by Nathalia Inacio on 19/03/2018.
//  Copyright © 2018 Nathalia Inacio. All rights reserved.
//

import SpriteKit
import GameplayKit

public class GameScene: SKScene {
    
    //music
    let finalDanceMusic = SKAudioNode(fileNamed: "finalDance.mp3")
    let blackSwanMusic = SKAudioNode(fileNamed: "blackSwan.mp3")
    let whiteSwanMusic = SKAudioNode(fileNamed: "whiteSwan.mp3")
    let backgroundMusic = SKAudioNode(fileNamed: "initialSong.mp3")
    
    //ballerina
    var isDancingBlack = false
    var isDancingWhite = false
    var isDancingFinal = false
    
    //counter
    var blackCounter=0
    var whiteCounter=0
    
    //timer
    var seconds = 20
    var timer:Timer?
    private var timerLabel : SKLabelNode?
    
   
    public func resetTimer() {
        
        seconds = 20
        timer?.invalidate()
        self.timerLabel!.text = "00:\(self.seconds)"
    }
    
    public func runTimer(){
        self.timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { _ in
            self.updateTimer()
        })
    }
    
    public func pauseTimer() {
        if !(timer?.isValid)! {
            runTimer()
        } else {
            timer?.invalidate()
        }
    }
    
    public func updateTimer(){
        
        seconds -= 1
        
        if seconds < 10 {
            self.timerLabel!.text = "00:0\(self.seconds)"
            
        } else {
            self.timerLabel!.text = "00:\(self.seconds)"
        }
        
        if seconds == 0 {
            
            timer?.invalidate()
            
            
            if(isDancingWhite || isDancingBlack){
                
                ballerinaNode?.removeAllActions()
                
                if(isDancingWhite){
                    
                    ballerinaNode?.texture = SKTexture(imageNamed: "whiteSwan0")
                    
                }
                
                else{
                    
                    ballerinaNode?.texture = SKTexture(imageNamed: "blackSwan0")
                    
                }
                
            }
            
            
            //gravity in the feathers
            physicsWorld.gravity = CGVector(dx: 0, dy: -5)
            
            
            let whiteFeathers = [whiteFeather1Node, whiteFeather2Node, whiteFeather3Node, whiteFeather4Node, whiteFeather5Node, whiteFeather6Node, whiteFeather7Node, whiteFeather8Node, whiteFeather9Node, whiteFeather10Node, whiteFeather11Node, whiteFeather12Node]
            
            for feather in whiteFeathers {
                    feather?.physicsBody=SKPhysicsBody(circleOfRadius:((feather?.size.width)!/2))
                    feather?.physicsBody?.affectedByGravity=true
            }
            
              let blackFeathers = [blackFeather1Node, blackFeather2Node, blackFeather3Node, blackFeather4Node, blackFeather5Node, blackFeather6Node, blackFeather7Node, blackFeather8Node, blackFeather9Node, blackFeather10Node, blackFeather11Node, blackFeather12Node]
            
            for feather in blackFeathers {
                feather?.physicsBody=SKPhysicsBody(circleOfRadius:((feather?.size.width)!/2))
                feather?.physicsBody?.affectedByGravity=true
            }
            
            
                //final dance
            
                backgroundMusic.run(.stop())
                whiteSwanMusic.run(.stop())
                blackSwanMusic.run(.stop())
                finalDanceMusic.run(.play())
            
            
            
                let dance = SKAction.repeat(SKAction.animate(with: finalDanceFrames,
                                                             timePerFrame: 0.1825,
                                                             resize: false,
                                                             restore: true), count: 2)
        
            
                
                let stopDancing2 = SKAction.run {
                    self.isDancingFinal = false
                    self.finalDanceMusic.run(.stop())
                }
                
                let danceAndStop = SKAction.sequence([dance, stopDancing2])
            
          
                ballerinaNode!.run(danceAndStop, withKey:"blackSwanDance")
            
                isDancingFinal = true
                ballerinaNode?.isPaused=false


            
                moralLabel?.zPosition=14
                moralsparkNode?.zPosition=7
                magicEmitter?.zPosition = 10
                magic2Emitter?.zPosition = 10
                
                ballerinaNode?.isPaused = false
                ballerinaNode?.texture = SKTexture(imageNamed: "finalDance0")
                resetTimer()
                whiteCounter=0
                blackCounter=0
                
    
            
        }
    }
    
    
    //ice block
    private var iceBlock : SKSpriteNode?
    
    //white feathers
    private var whiteFeather1Node : SKSpriteNode?
    private var whiteFeather2Node : SKSpriteNode?
    private var whiteFeather3Node : SKSpriteNode?
    private var whiteFeather4Node : SKSpriteNode?
    private var whiteFeather5Node : SKSpriteNode?
    private var whiteFeather6Node : SKSpriteNode?
    private var whiteFeather7Node : SKSpriteNode?
    private var whiteFeather8Node : SKSpriteNode?
    private var whiteFeather9Node : SKSpriteNode?
    private var whiteFeather10Node : SKSpriteNode?
    private var whiteFeather11Node : SKSpriteNode?
    private var whiteFeather12Node : SKSpriteNode?
    
    //black feathers
    private var blackFeather1Node : SKSpriteNode?
    private var blackFeather2Node : SKSpriteNode?
    private var blackFeather3Node : SKSpriteNode?
    private var blackFeather4Node : SKSpriteNode?
    private var blackFeather5Node : SKSpriteNode?
    private var blackFeather6Node : SKSpriteNode?
    private var blackFeather7Node : SKSpriteNode?
    private var blackFeather8Node : SKSpriteNode?
    private var blackFeather9Node : SKSpriteNode?
    private var blackFeather10Node : SKSpriteNode?
    private var blackFeather11Node : SKSpriteNode?
    private var blackFeather12Node : SKSpriteNode?
    
    
    //loses
    private var fadeout1 : SKSpriteNode?
    private var fadeout2 : SKSpriteNode?
    private var losesLabel1 : SKLabelNode?
    private var losesLabel2 : SKLabelNode?
    
    //still dancing
    private var tapLabel1 : SKLabelNode?
    private var tapLabel2 : SKLabelNode?
    private var tapsparkNode : SKSpriteNode?

    //moral
    private var moralLabel : SKLabelNode?
    private var moralsparkNode : SKSpriteNode?
    
    
    //ballerina
    private var ballerinaNode : SKSpriteNode?
    private var ballerinaAfraid1Node : SKSpriteNode?
    private var ballerinaAfraid2Node : SKSpriteNode?
    
    //swans frames
    private var whiteSwanFrames: [SKTexture] = []
    private var blackSwanFrames: [SKTexture] = []
    private var finalDanceFrames: [SKTexture] = []
  
    //particles
    private var fireEmitter: SKEmitterNode!
    private var fire2Emitter: SKEmitterNode!
    private var fire3Emitter: SKEmitterNode!
    private var fire4Emitter: SKEmitterNode!
    private var fire5Emitter: SKEmitterNode!
    private var magicEmitter: SKEmitterNode!
    private var magic2Emitter: SKEmitterNode!
    private var snowEmitter: SKEmitterNode!
   
    public override func didMove(to view: SKView) {
        
        //music
        
        self.addChild(backgroundMusic)
        self.addChild(whiteSwanMusic)
        self.addChild(blackSwanMusic)
        self.addChild(finalDanceMusic)
        
        backgroundMusic.run(.play())
        finalDanceMusic.run(.stop())
        whiteSwanMusic.run(.stop())
        blackSwanMusic.run(.stop())

        //timer
        runTimer()
        pauseTimer()
  
        //magic
        
        self.magicEmitter = SKEmitterNode(fileNamed: "magicParticle.sks")
        magicEmitter?.position = CGPoint(x: -467.277, y: 202.611)
        magicEmitter?.zPosition = -1
        self.addChild(magicEmitter!)
        
        self.magic2Emitter = SKEmitterNode(fileNamed: "magicParticle2.sks")
        magic2Emitter?.position = CGPoint(x: +467.277, y: 202.611)
        magic2Emitter?.zPosition = -1
        self.addChild(magic2Emitter!)
        
        
        //fire
        self.fireEmitter = SKEmitterNode(fileNamed: "fireParticle.sks")
        fireEmitter?.position = CGPoint(x: -35.766, y: -386.878)
        fireEmitter?.zPosition = -1
        self.addChild(fireEmitter!)
        
        self.fire2Emitter = SKEmitterNode(fileNamed: "fireParticle.sks")
        fire2Emitter?.position = CGPoint(x: 48.234, y: -386.878)
        fire2Emitter?.zPosition = -1
        self.addChild(fire2Emitter!)
        
        self.fire3Emitter = SKEmitterNode(fileNamed: "fireParticle.sks")
        fire3Emitter?.position = CGPoint(x: 8.587, y: -359.234)
        fire3Emitter?.zPosition = -1
        self.addChild(fire3Emitter!)
        
        self.fire4Emitter = SKEmitterNode(fileNamed: "fireParticle.sks")
        fire4Emitter?.position = CGPoint(x: 8.587, y: -359.234)
        fire4Emitter?.zPosition = -1
        self.addChild(fire4Emitter!)
        
        self.fire5Emitter = SKEmitterNode(fileNamed: "fireParticle.sks")
        fire5Emitter?.position = CGPoint(x: -15.913, y: -386.878)
        fire5Emitter?.zPosition = -1
        self.addChild(fire5Emitter!)
        
        
        //snow
        self.snowEmitter = SKEmitterNode(fileNamed: "snowParticle.sks")
        snowEmitter?.position = CGPoint(x: 20.087, y: 270.394)
        snowEmitter?.zPosition = -1
        self.addChild(snowEmitter!)
        
        
        
        //ice block
        self.iceBlock = self.childNode(withName: "//iceBlock") as? SKSpriteNode
        
        //timer
        self.timerLabel = self.childNode(withName: "//timer") as? SKLabelNode
        
        //moral
        self.moralLabel = self.childNode(withName: "//moral") as? SKLabelNode
        self.moralsparkNode = self.childNode(withName: "//spark4") as? SKSpriteNode
        
        
        //still dancing
        self.tapLabel1 = self.childNode(withName: "//tapLabel1") as? SKLabelNode
        self.tapLabel2 = self.childNode(withName: "//tapLabel2") as? SKLabelNode
        self.tapsparkNode = self.childNode(withName: "//spark2") as? SKSpriteNode
        
        //loses
        
        self.fadeout1 = self.childNode(withName: "//fadeout1") as? SKSpriteNode
        self.fadeout2 = self.childNode(withName: "//fadeout2") as? SKSpriteNode
        self.losesLabel1 = self.childNode(withName: "//loses1") as? SKLabelNode
        self.losesLabel2 = self.childNode(withName: "//loses2") as? SKLabelNode

    
        //white feathers
        self.whiteFeather1Node = self.childNode(withName: "//whiteFeather1") as? SKSpriteNode
        self.whiteFeather2Node = self.childNode(withName: "//whiteFeather2") as? SKSpriteNode
        self.whiteFeather3Node = self.childNode(withName: "//whiteFeather3") as? SKSpriteNode
        self.whiteFeather4Node = self.childNode(withName: "//whiteFeather4") as? SKSpriteNode
        self.whiteFeather5Node = self.childNode(withName: "//whiteFeather5") as? SKSpriteNode
        self.whiteFeather6Node = self.childNode(withName: "//whiteFeather6") as? SKSpriteNode
        self.whiteFeather7Node = self.childNode(withName: "//whiteFeather7") as? SKSpriteNode
        self.whiteFeather8Node = self.childNode(withName: "//whiteFeather8") as? SKSpriteNode
        self.whiteFeather9Node = self.childNode(withName: "//whiteFeather9") as? SKSpriteNode
        self.whiteFeather10Node = self.childNode(withName: "//whiteFeather10") as? SKSpriteNode
        self.whiteFeather11Node = self.childNode(withName: "//whiteFeather11") as? SKSpriteNode
        self.whiteFeather12Node = self.childNode(withName: "//whiteFeather12") as? SKSpriteNode
        
        //black feathers
        self.blackFeather1Node = self.childNode(withName: "//blackFeather1") as? SKSpriteNode
        self.blackFeather2Node = self.childNode(withName: "//blackFeather2") as? SKSpriteNode
        self.blackFeather3Node = self.childNode(withName: "//blackFeather3") as? SKSpriteNode
        self.blackFeather4Node = self.childNode(withName: "//blackFeather4") as? SKSpriteNode
        self.blackFeather5Node = self.childNode(withName: "//blackFeather5") as? SKSpriteNode
        self.blackFeather6Node = self.childNode(withName: "//blackFeather6") as? SKSpriteNode
        self.blackFeather7Node = self.childNode(withName: "//blackFeather7") as? SKSpriteNode
        self.blackFeather8Node = self.childNode(withName: "//blackFeather8") as? SKSpriteNode
        self.blackFeather9Node = self.childNode(withName: "//blackFeather9") as? SKSpriteNode
        self.blackFeather10Node = self.childNode(withName: "//blackFeather10") as? SKSpriteNode
        self.blackFeather11Node = self.childNode(withName: "//blackFeather11") as? SKSpriteNode
        self.blackFeather12Node = self.childNode(withName: "//blackFeather12") as? SKSpriteNode
        
        //ballerina
        self.ballerinaNode = self.childNode(withName: "//ballerina") as? SKSpriteNode
        self.ballerinaAfraid1Node = self.childNode(withName: "//ballerinaAfraid1") as? SKSpriteNode
        self.ballerinaAfraid2Node = self.childNode(withName: "//ballerinaAfraid2") as? SKSpriteNode
      
        buildWhiteSwan()
        
        buildBlackSwan()
       
        buildfinalDance()
       
        //white feathers movimentation
        let comesandgoes = SKAction.repeatForever(SKAction.sequence([SKAction.moveBy(x: 10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: 10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: 10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: 10, y: 10, duration: 0.4),
                                                                SKAction.moveBy(x: 10, y: 10, duration: 0.4),
                                                                SKAction.moveBy(x: 10, y: 10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: -10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: 10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: 10, duration: 0.4),
                                                                SKAction.moveBy(x: -10, y: 10, duration: 0.4)]))
        
        let whiteFeathers = [whiteFeather1Node, whiteFeather2Node, whiteFeather3Node, whiteFeather4Node, whiteFeather5Node, whiteFeather6Node, whiteFeather7Node, whiteFeather8Node, whiteFeather9Node, whiteFeather10Node, whiteFeather11Node, whiteFeather12Node]
       
        let rotateFeather = SKAction.rotate(byAngle: 2, duration: 10)
        let repeatRotationFeather = SKAction.repeatForever(rotateFeather)
        

        for feather in whiteFeathers {
            let randomtime = Double(arc4random()) / 0xFFFFFFFF
            let wait = SKAction.wait(forDuration: randomtime)
            let waitsandshakes = SKAction.sequence([wait, comesandgoes])
            let waitAndRotates = SKAction.sequence([wait, repeatRotationFeather])
            let group = SKAction.group([waitAndRotates, waitsandshakes])
            feather?.run(group)
        }
        
   
        
        //black feathers movimentation
        let blackFeathers = [blackFeather1Node, blackFeather2Node, blackFeather3Node, blackFeather4Node, blackFeather5Node, blackFeather6Node, blackFeather7Node, blackFeather8Node, blackFeather9Node, blackFeather10Node, blackFeather11Node, blackFeather12Node]
        
        for feather in blackFeathers {
            let randomtime = Double(arc4random()) / 0xFFFFFFFF
            let wait = SKAction.wait(forDuration: randomtime)
            let waitsandshakes = SKAction.sequence([wait, comesandgoes])
            let waitAndRotates = SKAction.sequence([wait, repeatRotationFeather])
            let group = SKAction.group([waitAndRotates, waitsandshakes])
            feather?.run(group)
        }
    }
    
    
    //white swan
    public func buildWhiteSwan() {
        
        var walkFrames: [SKTexture] = []
        
        for i in 0...23 {
            let whiteSwanTextureName = "whiteSwan\(i)"
            let texture = SKTexture(imageNamed: whiteSwanTextureName)
            walkFrames.append(texture)
            
        }
       
        whiteSwanFrames = walkFrames
     
    }
    
    //black swan
    public func buildBlackSwan() {
        
        var walkFrames: [SKTexture] = []
       
        for i in 0...11 {
            let blackSwanTextureName = "blackSwan\(i)"
            let texture = SKTexture(imageNamed: blackSwanTextureName)
            walkFrames.append(texture)
        
        }
        
        blackSwanFrames = walkFrames
        
    }
   
    //final dance
    public func buildfinalDance() {
      
        var walkFrames: [SKTexture] = []
        
    
        for i in 0...54 {
            let finalDanceTextureName = "finalDance\(i)"
            let texture = SKTexture(imageNamed: finalDanceTextureName)
            walkFrames.append(texture)
            
        }
        
        finalDanceFrames = walkFrames
        
    }

     
    
    //touch the feather and dance
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       
        if !isDancingWhite && !isDancingBlack && !isDancingFinal {
            let touch:UITouch = touches.first!
            let positionInScene = touch.location(in: self)
            let touchedNode = self.atPoint(positionInScene)
            
            tapLabel1?.zPosition = -1
            tapLabel2?.zPosition = -1
            tapsparkNode?.zPosition = -1
            
            
            //white swan
            if (touchedNode.name == "whiteFeather1" ||  touchedNode.name == "whiteFeather2" ||  touchedNode.name == "whiteFeather3" || touchedNode.name == "whiteFeather4" || touchedNode.name == "whiteFeather5" || touchedNode.name == "whiteFeather6" || touchedNode.name == "whiteFeather7" || touchedNode.name == "whiteFeather8" || touchedNode.name == "whiteFeather9" || touchedNode.name == "whiteFeather10" || touchedNode.name == "whiteFeather11" || touchedNode.name == "whiteFeather12")
            {
                
                backgroundMusic.run(.stop())

                whiteSwanMusic.run(.play())
                
                blackSwanMusic.run(.stop())
                
                
                let whiteFeathers2 = [whiteFeather1Node, whiteFeather2Node, whiteFeather3Node, whiteFeather4Node, whiteFeather5Node, whiteFeather7Node, whiteFeather8Node, whiteFeather9Node, whiteFeather10Node, whiteFeather11Node, whiteFeather12Node]
                
                let blackFeathers2 = [blackFeather1Node, blackFeather2Node, blackFeather3Node, blackFeather5Node, blackFeather6Node, blackFeather7Node, blackFeather8Node, blackFeather9Node, blackFeather10Node, blackFeather11Node, blackFeather12Node]
                
                for feather in blackFeathers2 {
                    feather?.isPaused=false
                }
                
                for feather in whiteFeathers2 {
                    feather?.isPaused=false
                }
                
                
                pauseTimer()
               
                iceBlock?.zPosition = -1
                fireEmitter?.zPosition = -1
                fire2Emitter?.zPosition = -1
                fire3Emitter?.zPosition = -1
                fire4Emitter?.zPosition = -1
                fire5Emitter?.zPosition = -1
                snowEmitter?.zPosition = -1
                ballerinaNode?.zPosition = 10
                ballerinaAfraid1Node?.zPosition = -1
                ballerinaAfraid2Node?.zPosition = -1
                moralLabel?.zPosition = -1
                moralsparkNode?.zPosition = -1
                losesLabel1?.zPosition = -1
                losesLabel2?.zPosition = -1
                
                fadeout1?.zPosition = -1
                fadeout2?.zPosition = -1
                
                
                whiteCounter += 1
                blackCounter = 0
                touchedNode.alpha = 0.0
                touchedNode.run(SKAction.fadeIn(withDuration: 2.0))
                
                if(whiteCounter == 2)
                    
                {
                    ballerinaNode?.isPaused = true
                    ballerinaNode?.removeAction(forKey: "whiteSwanDance")
                    isDancingWhite = false
                    ballerinaNode?.texture = SKTexture(imageNamed: "whiteSwan0")
                    ballerinaNode?.zPosition = -1
                    ballerinaAfraid1Node?.zPosition = 10
                    iceBlock?.zPosition = 14.505
                    snowEmitter?.zPosition = 16
                    fadeout1?.zPosition = 17
                    fadeout2?.zPosition = 17
                    
                    for feather in whiteFeathers2 {
                        feather?.isPaused=true
                    }
                    
                    for feather in blackFeathers2 {
                        feather?.isPaused=true
                    }
                    
                    moralsparkNode?.zPosition=18
                    losesLabel1?.zPosition = 36
                    losesLabel2?.zPosition = 36
                    
                    whiteCounter=0
                    resetTimer()
                    
                } else {
                    
                    let dance = SKAction.repeat(SKAction.animate(with: whiteSwanFrames,
                                                                 timePerFrame: 0.10,
                                                                 resize: false,
                                                                 restore: true), count: 2)
                    
                    let stopDancing = SKAction.run {
                        self.isDancingWhite = false
                        self.pauseTimer()
                        self.whiteSwanMusic.run(.stop())
                        self.backgroundMusic.run(.play())
                        
                    }
                    
                    let danceAndStop = SKAction.sequence([dance, stopDancing])
                    
                    ballerinaNode!.run(danceAndStop, withKey:"whiteSwanDance")
                    isDancingWhite = true
                    ballerinaNode?.texture = SKTexture(imageNamed: "whiteSwan0")
                    ballerinaNode?.isPaused=false

                }
                
            }
            
            
            //black swan
            if (touchedNode.name == "blackFeather1" ||  touchedNode.name == "blackFeather2" ||  touchedNode.name == "blackFeather3" || touchedNode.name == "blackFeather4" || touchedNode.name == "blackFeather5" || touchedNode.name == "blackFeather6" || touchedNode.name == "blackFeather7" || touchedNode.name == "blackFeather8" || touchedNode.name == "blackFeather9" || touchedNode.name == "blackFeather10" || touchedNode.name == "blackFeather11" || touchedNode.name == "blackFeather12")
            {
                
                backgroundMusic.run(.stop())
                
                whiteSwanMusic.run(.stop())
                
                blackSwanMusic.run(.play())
                
                let whiteFeathers2 = [whiteFeather1Node, whiteFeather2Node, whiteFeather3Node, whiteFeather4Node, whiteFeather5Node, whiteFeather7Node, whiteFeather8Node, whiteFeather9Node, whiteFeather10Node, whiteFeather11Node, whiteFeather12Node]
                
                let blackFeathers2 = [blackFeather1Node, blackFeather2Node, blackFeather3Node, blackFeather5Node, blackFeather6Node, blackFeather7Node, blackFeather8Node, blackFeather9Node, blackFeather10Node, blackFeather11Node, blackFeather12Node]
                
                
                
                for feather in blackFeathers2 {
                    feather?.isPaused=false
                }
                
                for feather in whiteFeathers2 {
                    feather?.isPaused=false
                }
                
          
                iceBlock?.zPosition = -1
                fireEmitter?.zPosition = -1
                fire2Emitter?.zPosition = -1
                fire3Emitter?.zPosition = -1
                fire4Emitter?.zPosition = -1
                fire5Emitter?.zPosition = -1
                snowEmitter?.zPosition = -1
                ballerinaNode?.zPosition = 10
                ballerinaAfraid2Node?.zPosition = -1
                ballerinaAfraid1Node?.zPosition = -1
                moralLabel?.zPosition = -1
                moralsparkNode?.zPosition = -1
                losesLabel1?.zPosition = -1
                losesLabel2?.zPosition = -1
                fadeout1?.zPosition = -1
                fadeout2?.zPosition = -1
            
                
                pauseTimer()
                
                whiteCounter = 0
                blackCounter += 1
                
                
                touchedNode.alpha = 0.0
                touchedNode.run(SKAction.fadeIn(withDuration: 2.0))
               
                if(blackCounter == 2)
                    
                {
                    ballerinaNode?.isPaused = true
                    ballerinaNode?.removeAction(forKey: "blackSwanDance")
                    isDancingBlack = false
                    ballerinaNode?.texture = SKTexture(imageNamed: "blackSwan0")
                    ballerinaNode?.zPosition = -1
                    ballerinaAfraid2Node?.zPosition = 10
                    fireEmitter?.zPosition = 16
                    fire2Emitter?.zPosition = 16
                    fire3Emitter?.zPosition = 0
                    fire4Emitter?.zPosition = 16
                    fire5Emitter?.zPosition = 16
                    fadeout1?.zPosition = 17
                    fadeout2?.zPosition = 17
                    blackCounter=0
                    resetTimer()
                    

                    for feather in whiteFeathers2 {
                        feather?.isPaused=true
                    }
                    
                    for feather in blackFeathers2 {
                        feather?.isPaused=true
                    }
                    
                    moralsparkNode?.zPosition=18
                    losesLabel1?.zPosition = 36
                    losesLabel2?.zPosition = 36
                    
                } else {
                    
                    let dance = SKAction.repeat(SKAction.animate(with: blackSwanFrames,
                                                                 timePerFrame: 0.30,
                                                                 resize: false,
                                                                 restore: true), count: 2)
                    
                    let stopDancing = SKAction.run {
                        self.isDancingBlack = false
                        self.pauseTimer()
                        self.blackSwanMusic.run(.stop())
                        self.backgroundMusic.run(.play())
                    }
                    
                    let danceAndStop = SKAction.sequence([dance, stopDancing])
                    
                    ballerinaNode!.run(danceAndStop, withKey:"blackSwanDance")
                    isDancingBlack = true
                    ballerinaNode?.texture = SKTexture(imageNamed: "blackSwan0")
                    ballerinaNode?.isPaused=false
 
                    
                }
                
               
            }
            
        }
        
        else{
            
            
            tapLabel1?.zPosition = 10
            tapLabel2?.zPosition = 10
            tapsparkNode?.zPosition = 9
            
            let sendToBack = SKAction.run {
                self.tapLabel1?.zPosition = -1
                self.tapLabel2?.zPosition = -1
                self.tapsparkNode?.zPosition = -1
            }
            
            let wait = SKAction.wait(forDuration: 3)
            let waitAndSend = SKAction.sequence([wait, sendToBack])
            
            run(waitAndSend)
        }
        
    }
    
    public override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
 
}

